﻿function openLocalConfiguration() {
    window.alert("This will be released in a future build.");
}

function createLocalConfiguration() {
    window.alert("This will be released in a future build.");
}